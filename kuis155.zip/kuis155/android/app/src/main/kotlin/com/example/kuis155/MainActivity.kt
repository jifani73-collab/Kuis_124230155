package com.example.kuis155

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
