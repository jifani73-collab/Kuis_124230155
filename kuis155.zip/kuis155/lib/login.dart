import 'package:flutter/material.dart';
import 'package:kuis155/home.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController UsernameConteroller = TextEditingController();
    final TextEditingController PasswordControllet = TextEditingController();

    void login (){
      String validUsername = "johan";
      String validPassword = "155";

      if (UsernameConteroller.text == validUsername && PasswordControllet.text == validPassword){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Login berhasil")) );
       
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => homepage(Username: validUsername),),);
      }else{
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Login Gagal")) );
    }
    }

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal:50),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
      
        children:[
          Text("Login", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
          Text("Welcome back to MiniLens!"),
          SizedBox(height: 80,),
          TextField(controller: UsernameConteroller,decoration: InputDecoration(hintText: "Username"),),
          SizedBox(height: 40,),
          TextField(controller: PasswordControllet,decoration: InputDecoration(hintText: "Password"),),
          SizedBox(height: 60,),
          SizedBox(
            height: 50,
            width: double.infinity,
            child: ElevatedButton(onPressed: login, child: Text("Login"))
          
          ),
        ],
            ),
      ),
    );
  }
}
