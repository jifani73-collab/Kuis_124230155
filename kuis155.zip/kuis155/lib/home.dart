import 'package:flutter/material.dart';
import 'package:kuis155/login.dart';
import 'package:kuis155/movie_model.dart';
import 'package:kuis155/movie_data.dart';


class homepage extends StatefulWidget {
  final String Username;
  const homepage({super.key, required this.Username});

  @override
  State<homepage> createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("hi, ${widget.Username}"),
        actions: [
          IconButton(onPressed: (){
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen(),),
              (rote) => false,
              );
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: GridView.builder(
        itemCount: movieList.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
        ),
        itemBuilder: (context, index) {
          return Card(
            child: Center(
              child: Text("Selamat datang ${widget.Username}"),
            ),
          );
        },
      ),
    );
  }
}